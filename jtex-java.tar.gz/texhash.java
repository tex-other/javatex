/*16:*/
/*1:*/
package javaTeX;

import java.awt.*;
import java.io.*;
import java.util.*;
import javaTeX.*;/*:1*/

public class texhash{
public static void main(String[]args){
TeXFile.makeHash();
}
}/*:16*/
